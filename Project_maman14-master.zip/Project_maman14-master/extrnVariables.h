#ifndef EXTRN_VARIABLES_H
#define EXTRN_VARIABLES_H


#endif
